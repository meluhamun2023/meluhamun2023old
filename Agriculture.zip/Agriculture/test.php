<?php
class Test{

    // Connection instance
    private $connection;

    // table name
    private $table_name = "asdf";

    // table columns
    

    public function __construct($connection){
        $this->connection = $connection;
    }
    //C
    public function create($crop_name,$problem_type,$caused_by,$crop_stage,$season,$parts_affected,$nature_of_damage){
        $sql = "INSERT INTO users (email,`name`,username,`password`,`type`,approves_crop,approves_problem,approves_problem_type) VALUES ('$crop_name','$problem_type','$caused_by','$crop_stage','$season','$parts_affected','$nature_of_damage')";
        $this->connection->query($sql);
    }
    //R
    public function read(){
        // $sql = "SELECT * FROM asdf";
        // $result = $this->connection->query($sql);
        // foreach($result as $row){
        //      printf("%s (%s) (%s)\n", $row[0], $row[1], $row[2]);
        //  }
        //  return $result;
    }
    //U
    public function update(){}
    //D
    public function delete(){}    
}