<?php

use function PHPSTORM_META\type;

include('./dbconfig.php');
include('./Database.php');
include('./test.php');
include('./userSchema.php');
header('Content-Type: application/json');
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
    $db = new DBClass();
    $getconn = $db->getConnection();
    $user = new UserSchema($getconn);
    $string = file_get_contents("php://input");
    $data = json_decode($string,true);
    $user->email = $data['email'];
    $user->name = $data['name'];
    $user->username = $data['username'];
    $user->password = $data['password'];
    $user->type = $data['type'];
    $user->approves_crop = $data['approves_crop'];
    $user->approves_problem= $data['approves_problem'];
    $user->approves_problem_type= $data['approves_problem_type'];
    //$con = mysqli_connect("localhost","root","root","root","Agriculture");
    $con = mysqli_connect("localhost","root","root","Agriculture");
    $msg = "";
    $result = mysqli_query($con,"SELECT * FROM users where `email`='$user->email'");
    $jsonArray = array();
    while($row = mysqli_fetch_assoc($result)){
        $jsonArray[] = $row;
    }
    if(count($jsonArray)){
        $msg = "Email Id already exists";
    }else{
        $result = mysqli_query($con,"SELECT * FROM users where username='$user->username'");
        $jsonArray = array();
        while($row = mysqli_fetch_assoc($result)){
            $jsonArray[] = $row;
        }
        if(count($jsonArray)){
            $msg = "Username already exists";
        }else{
            $result = mysqli_query($con,"SELECT * FROM users where (approves_crop='$user->approves_crop' and approves_problem='$user->approves_problem' and approves_problem_type='$user->approves_problem_type')");
            $jsonArray = array();
            while($row = mysqli_fetch_assoc($result)){
                $jsonArray[] = $row;
            }
            if(count($jsonArray) and $user->type === "Approver"){
                $msg = "Approver for the crop/cause already exists";
            }else{
                $user->create($user->email,$user->name,$user->username,$user->password,$user->type,$user->approves_crop,$user->approves_problem,$user->approves_problem_type);
                $msg = "User Added Successfully";
            }
        }
    }
     print($msg);
?>