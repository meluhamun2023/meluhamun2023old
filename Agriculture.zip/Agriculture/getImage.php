<?php
include('./Database.php');
header('Content-Type: application/json');
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
$db = new DBClass();
$getconn = $db->getConnection();
$target_dir = "uploads/";
$target_file = $target_dir . basename($name);
if(file_exists($target_file)){
    header("Cache-Control: public");
    header("Content-Description: File Transfer");
    header("Content-Disposition: attachment; filename=$target_file");
    header("Content-Type: application/zip");
    header("Content-Transfer-Encoding: binary");
    echo readfile($target_file);
}else{
    //echo "not";
}
?>