<?php

use function PHPSTORM_META\type;

include('./dbconfig.php');
include('./Database.php');
include('./cropSchema.php');
header('Content-Type: application/json');
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
    $db = new DBClass();
    $getconn = $db->getConnection();
    $cropSchema = new CropSchema($getconn);
    $con = mysqli_connect("localhost","root","root","Agriculture");
    //$con = mysqli_connect("localhost","root","root","root","Agriculture");
    $result = mysqli_query($con,"SELECT * from users where type='User' and username!=''");
    $jsonArray = array();
    while($row = mysqli_fetch_assoc($result)){
        $jsonArray[] = $row;
    }
    print(json_encode($jsonArray));
    //$cropSchema->update($crop_name,$problem_type,$caused_by,$crop_stage,$season,$parts_affected,$nature_of_damage,$imgurl,$ETL,$measures,$id,$stage);
?>