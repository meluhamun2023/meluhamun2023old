<?php

use function PHPSTORM_META\type;

include('./dbconfig.php');
include('./Database.php');
include('./test.php');
header('Content-Type: application/json');
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
    $db = new DBClass();
    $getconn = $db->getConnection();
    $test = new Test($getconn);
    $string = file_get_contents("php://input");
    $data = json_decode($string,true);
     //$con = mysqli_connect("localhost","root","root","root","Agriculture");
     $con = mysqli_connect("localhost","root","root","Agriculture");
     $id = $data['id'];
     $response = $data['response'];
     $checked_by = $data['checked_by'];
     $checked_on = $data['checked_on'];
     $result = mysqli_query($con,"UPDATE crop SET stage='$response', checked_by='$checked_by', checked_on='$checked_on'  where id='$id' ");
     $jsonArray = array();
        while($row = mysqli_fetch_assoc($result)){
        $jsonArray[] = $row;
    }
?>