<?php

use function PHPSTORM_META\type;
include('./dbconfig.php');
include('./Database.php');
include('./cropSchema.php');
include('./test.php');
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
header("Access-Control-Allow-Headers: *");
 $db = new DBClass();
    $getconn = $db->getConnection();
    $string = file_get_contents("php://input");
    $data = json_decode($string,true);
    $approves_crop =  $data['approves_crop'];
    $approves_problem = $data['approves_problem'];
    $approves_problem_type = $data['approves_problem_type'];
    /*$state = $data['state'];
    $nestedPest = $data['nestedPest'];
    $place = $data['place'];
    $year = $data['year'];
    $mode = $data['mode'];*/
    $con = mysqli_connect("localhost","root","root","Agriculture");
    //$con = mysqli_connect("localhost","root","root","root","Agriculture");
    if($approves_problem=="Natural Enemies" or $approves_problem=="Others"){
        $sql = "SELECT * FROM crop where crop_name='$approves_crop' and problem_type='$approves_problem'";
    }else{
        $sql = "SELECT * FROM crop where crop_name='$approves_crop' and caused_by='$approves_problem' and problem_type='$approves_problem_type'";
    }
    /*and `state`='$state' and nestedPest='$nestedPest' and place='$place' and `year`='$year' and mode='$mode'*/
    $result = mysqli_query($con,$sql);
    $jsonArray = array();
    while($row = mysqli_fetch_assoc($result)){
        $jsonArray[] = $row;
    }
    print(json_encode($jsonArray));
?>