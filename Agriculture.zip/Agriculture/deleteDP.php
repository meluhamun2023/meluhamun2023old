<?php
include('./Database.php');
header('Content-Type: application/json');
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
$db = new DBClass();
$getconn = $db->getConnection();
 $string = file_get_contents("php://input");
 $data = json_decode($string,true);
 $diseaseName = $data['diseaseName'];
 $damage_type = $data['damage_type'];
 $crop_name = $data['crop_name'];
$con = mysqli_connect("localhost","root","root","Agriculture");
$result = mysqli_query($con,"DELETE FROM crop_names where problem_type='$damage_type' and caused_by='$diseaseName' and crop_name='$crop_name' ");
$result = mysqli_query($con,"SELECT * FROM crop_names where problem_type='$damage_type' and caused_by='$diseaseName' and crop_name='$crop_name' ");
$jsonArray = array();
while($row = mysqli_fetch_assoc($result)){
    $jsonArray[] = $row;
}
$msg = "";
if(count($jsonArray)==0){
    $msg = "Crop Deleted Successfully.";
}else{
    $msg = "Something went wrong! Please try again.";
}
print($msg);
?>