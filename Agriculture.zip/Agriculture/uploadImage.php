<?php
$allowedOrigins = array(
    '(http(s)://)?(www\.)?my\-domain\.com'
  );
  if (isset($_SERVER['HTTP_ORIGIN']) && $_SERVER['HTTP_ORIGIN'] != '') {
    foreach ($allowedOrigins as $allowedOrigin) {
      if (preg_match('#' . $allowedOrigin . '#', $_SERVER['HTTP_ORIGIN'])) {
        header('Access-Control-Allow-Origin: ' . $_SERVER['HTTP_ORIGIN']);
        header('Access-Control-Allow-Methods: GET, PUT, POST, DELETE, OPTIONS');
        header('Access-Control-Max-Age: 1000');
        header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
        break;
      }
    }
  }
include('./Database.php');
header('Content-Type: application/json');
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Origin: *");
//header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
header("Access-Control-Allow-Headers: *");
$db = new DBClass();
$getconn = $db->getConnection();
$target_dir = "uploads/";
// print_r($_FILES['image_file']['name']);
// echo '<pre>'; var_export($_FILES['image_file']); echo '</pre>';
$length = rand(10,20);
$data = '1234567890ABCDEFGHIJKLMNOPQRSTUVWXYZabcefghijklmnopqrstuvwxyz';
$name =  substr(str_shuffle($data), 0, $length) . '.png';
$target_file = $target_dir . basename($name);
if(move_uploaded_file($_FILES["image_file"]["tmp_name"], $target_file)) {
    print($name);
}else{
    echo "fail";
}
?>
