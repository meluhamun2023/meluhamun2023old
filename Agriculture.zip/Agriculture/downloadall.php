<?php
include('./Database.php');
header('Content-Type: application/json');
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
$db = new DBClass();
$getconn = $db->getConnection();
$pathdir = "uploads/";
$newzip = new ZipArchive;
   if($newzip -> open('allfiles.zip', ZipArchive::CREATE ) === TRUE) {
      $dir = opendir($pathdir);
      while($file = readdir($dir)) {
         if(is_file($pathdir.$file)) {
            $newzip -> addFile($pathdir.$file, $file);
         }
      }
      $newzip ->close();
   }
?>