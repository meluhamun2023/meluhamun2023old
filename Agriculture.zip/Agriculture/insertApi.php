<?php

use function PHPSTORM_META\type;

include('./dbconfig.php');
include('./Database.php');
include('./cropSchema.php');
include('./test.php');
header('Content-Type: application/json');
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
$db = new DBClass();
$getconn = $db->getConnection();
$cropSchema = new CropSchema($getconn);
//$test = new Test($getconn);
$string = file_get_contents("php://input");
$data = json_decode($string, true);
$cropSchema->id = $data['id'];
$cropSchema->crop_name = $data['crop_name'];
$cropSchema->problem_type = $data['problem_type'];
$cropSchema->caused_by = $data['caused_by'];
$cropSchema->crop_stage = $data['crop_stage'];
$cropSchema->season = $data['season'];
$cropSchema->parts_affected = $data['parts_affected'];
//$cropSchema->nature_of_damage = $data['nature_of_damage'];
$cropSchema->images = $data['images'];
$cropSchema->scientific_name = $data['scientific_name'];
$cropSchema->stage = $data['stage'];
$cropSchema->checked_by = $data['checked_by'];
$cropSchema->uploaded_on = $data['uploaded_on'];
$cropSchema->checked_on = $data['checked_on'];
$cropSchema->state = $data['state'];
$cropSchema->nestedPest = $data['nestedPest'];
$cropSchema->place = $data['place'];
$cropSchema->year = $data['year'];
$cropSchema->mode = $data['mode'];
$cropSchema->month = $data['month'];
$cropSchema->dpStage = $data['dp_stage'];


$cropSchema->create(
    $cropSchema->id,
    $cropSchema->crop_name,
    $cropSchema->problem_type,
    $cropSchema->caused_by,
    $cropSchema->crop_stage,
    $cropSchema->season,
    $cropSchema->parts_affected,
    //$cropSchema->nature_of_damage,
    $cropSchema->images,
    $cropSchema->scientific_name,
    $cropSchema->stage,
    $cropSchema->checked_by,
    $cropSchema->uploaded_on,
    $cropSchema->checked_on,
    $cropSchema->state,
    $cropSchema->nestedPest,
    $cropSchema->place,
    $cropSchema->year,
    $cropSchema->mode,
    $cropSchema->month,
    $cropSchema->dpStage
);
