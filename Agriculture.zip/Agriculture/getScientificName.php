<?php

use function PHPSTORM_META\type;
include('./dbconfig.php');
include('./Database.php');
header('Content-Type: application/json');
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
    $db = new DBClass();
    $getconn = $db->getConnection();
    $string = file_get_contents("php://input");
    $data = json_decode($string,true);
    $caused_by = $data['caused_by'];
    $con = mysqli_connect("localhost","root","root","Agriculture");
    $result = mysqli_query($con,"SELECT scientific_name FROM crop_names where caused_by='$caused_by'");
    $jsonArray = array();
    while($row = mysqli_fetch_assoc($result)){
        $jsonArray[] = $row;
    }
    //print_r($jsonArray);
    print(json_encode($jsonArray));
?>