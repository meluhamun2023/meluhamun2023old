<?php
include('./Database.php');
header('Content-Type: application/json');
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
$db = new DBClass();
$getconn = $db->getConnection();
$string = file_get_contents("php://input");
$data = json_decode($string,true);
$crop_name = $data['crop_name'];
$scientific_name = $data['scientific_name'];
$caused_by = $data['caused_by'];
$problem_type = $data['problem_type'];
$con = mysqli_connect("localhost","root","root","Agriculture");
$result = mysqli_query($con,"INSERT into `crop_names` (`crop_name`,`problem_type`,`caused_by`,`scientific_name`) VALUES ('$crop_name','$problem_type','$caused_by','$scientific_name')");
$msg = $problem_type . " added successfully";
print($msg);
?>