<?php
include('./Database.php');
header('Content-Type: application/json');
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
$db = new DBClass();
$getconn = $db->getConnection();
$string = file_get_contents("php://input");
$data = json_decode($string,true);
$crop_name = $data['crop_name'];
$damate_type = $data['damage_type'];
$caused_by = $data['caused_by'];
$stage = $data['stage'];
$pathdir = "uploads/";
$temppath = "temp/";
$newzip = new ZipArchive;
//$con = mysqli_connect("localhost","root","root","root","Agriculture");
$con = mysqli_connect("localhost","root","root","Agriculture");
if($stage!="" && $stage!=null){
    $result = mysqli_query($con,"SELECT images from crop where `crop_name`='$crop_name' and `problem_type`='$damate_type' and `dpStage`='$stage' and `caused_by`='$caused_by'");
}else{
    $result = mysqli_query($con,"SELECT images from crop where `crop_name`='$crop_name' and `problem_type`='$damate_type' and `caused_by`='$caused_by'");
}
$selectedurls = array();
while($row = mysqli_fetch_assoc($result)){
    $selectedurls = preg_split("/\,/", $row["images"]);
}

// echo sizeof($selectedurls);

    if(file_exists('selectedImages.zip')){
        unlink('selectedImages.zip');
    }
   if($newzip -> open('selectedImages.zip', ZipArchive::CREATE ) === TRUE) {
      $dir = opendir($pathdir);
      while($file = readdir($dir)) {
          $res = substr($pathdir.$file,8,strlen($pathdir.$file));
            if(is_file($pathdir.$file)) {
                if(in_array($res,$selectedurls)){
                    // echo $res;
                    // echo "\n";
                    $newzip -> addFile($pathdir.$file, $file);
                }else{
                    // echo "no data";
                    // echo "\n";
                }
         }
      }
      $newzip ->close();
      //echo sizeof($selectedurls);

   }
?>