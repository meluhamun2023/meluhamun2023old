<?php
include('./Database.php');
header('Content-Type: application/json');
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
$db = new DBClass();
$getconn = $db->getConnection();
//$con = mysqli_connect("localhost","root","root","root","Agriculture");
$con = mysqli_connect("localhost","root","root","Agriculture");
$result = mysqli_query($con,"DELETE * from crop_names");
?>