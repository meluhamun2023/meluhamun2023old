<?php
include('./Database.php');
header('Content-Type: application/json');
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
$db = new DBClass();
$getconn = $db->getConnection();
 $string = file_get_contents("php://input");
 $data = json_decode($string,true);
 $crop_name = $data['crop_name'];
 $damage_type = $data['damage_type'];
 $caused_by = $data['caused_by'];
 //$scientific_name = $data['scientific_name'];
$con = mysqli_connect("localhost","root","root","Agriculture");
$result = mysqli_query($con,"SELECT * FROM crop_names where crop_name='$crop_name' and problem_type='$damage_type' and caused_by='$caused_by'");
$jsonArray = array();
while($row = mysqli_fetch_assoc($result)){
    $jsonArray[] = $row;
}
$msg = "";
if(count($jsonArray)){
    $msg = "Crop with Disease/Pest already exists";
}else{
    $result = mysqli_query($con,"INSERT into `crop_names` (`crop_name`,`problem_type`,`caused_by`) VALUES ('$crop_name','$damage_type','$caused_by')");
    $msg = "Crop added successfully";
}
print($msg);
?>