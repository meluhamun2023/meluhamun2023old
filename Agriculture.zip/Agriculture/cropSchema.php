<?php
class CropSchema
{

    // Connection instance
    private $connection;

    // table name
    private $table_name = "crop";

    // table columns
    public $id;
    public $crop_name;
    public $problem_type;
    public $caused_by;
    public $crop_stage;
    public $season;
    public $parts_affected;
    //public $nature_of_damage;
    public $scientific_name;
    public $images;
    public $state;
    public $nestedPest;
    public $place;
    public $year;
    public $mode;
    public $checked_by;
    public $stage;
    public $uploaded_on;
    public $checked_on;
    public $month;
    public $dpStage;



    public function __construct($connection)
    {
        $this->connection = $connection;
    }
    //C
    function create($id, $crop_name, $problem_type, $caused_by, $crop_stage, $season, $parts_affected, $images, $scientific_name, $stage, $checked_by, $uploaded_on, $checked_on, $state, $nestedPest, $place ,$year, $mode, $month, $dpStage)
    {
        $sql = "INSERT INTO crop (`id`,`crop_name`,`problem_type`,`caused_by`,`crop_stage`,`season`,`parts_affected`,`scientific_name`,`images`, `stage`, `checked_by`, `uploaded_on`, `checked_on`, `state`, `nestedPest`, `place`, `year`, `mode`, `month`,`dpStage`) VALUES ('$id','$crop_name','$problem_type','$caused_by','$crop_stage','$season','$parts_affected','$scientific_name','$images', '$stage', '$checked_by', '$uploaded_on', '$checked_on', '$state', '$nestedPest', '$place', '$year', '$mode','$month','$dpStage')";
        echo $sql;
        $this->connection->query($sql);
        
    }
    //R
    function read()
    {
    }
    //U
    // public function update($crop_name,$problem_type,$caused_by,$crop_stage,$season,$parts_affected,$nature_of_damage,$images,$id,$stage){
    //     $sql = "UPDATE `crop` SET `crop_name`='$crop_name' , `problem_type`='$problem_type' , `caused_by`='$caused_by',`crop_stage`='$crop_stage',`season`='$season',`parts_affected`='$parts_affected',`nature_of_damage`='$nature_of_damage',`images`='$images',`stage`='$stage' where `id`=$id";
    //     $this->connection->query($sql);
    // }
    //D
    function delete()
    {
    }
}
