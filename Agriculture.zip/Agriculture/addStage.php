<?php
include('./Database.php');
header('Content-Type: application/json');
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
$db = new DBClass();
$getconn = $db->getConnection();
 $string = file_get_contents("php://input");
 $data = json_decode($string,true);
 $problem = $data['problem'];
 $stagename = $data['stagename'];
$con = mysqli_connect("localhost","root","root","Agriculture");
if($problem=="Pest"){
    $result = mysqli_query($con,"SELECT * FROM pest_stages where pestName='$stagename'");
}else{
    $result = mysqli_query($con,"SELECT * FROM disease_stages where diseaseName='$stagename'");
}
$jsonArray = array();
while($row = mysqli_fetch_assoc($result)){
    $jsonArray[] = $row;
}
$msg = "";
if(count($jsonArray)){
    $msg = "$stagename with $problem already exists";
}else{
    if($problem=="Pest"){
        $result = mysqli_query($con,"INSERT into `pest_stages` (`pestName`) VALUES ('$stagename')");
    }else{
        $result = mysqli_query($con,"INSERT into `disease_stages` (`diseaseName`) VALUES ('$stagename')");
    }
    $msg = "Stage added successfully";
}
print($msg);
?>