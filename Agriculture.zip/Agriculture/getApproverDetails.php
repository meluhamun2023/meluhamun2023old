<?php

use function PHPSTORM_META\type;

include('./dbconfig.php');
include('./Database.php');
header('Content-Type: application/json');
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
    $db = new DBClass();
    $getconn = $db->getConnection();
    $string = file_get_contents("php://input");
    $data = json_decode($string,true);
    $username = $data['username'];
    $password = $data['password'];
    //$con = mysqli_connect("localhost","root","root","root","Agriculture");
    $con = mysqli_connect("localhost","root","root","Agriculture");
    $sql = "SELECT * FROM users where username='$username' and password='$password'";
    $result = mysqli_query($con,$sql);
    $jsonArray = array();
    while($row = mysqli_fetch_assoc($result)){
        $jsonArray[] = $row;
    }
    print(json_encode($jsonArray));
?>