<?php
 $dbhost = "localhost";
 $dbuser = "root";
 $dbpass = "root";
 //$dbpass = "Xx4[mw1<lz{!4j(~";
 //$db = "id18067807_agriculture";
 $db = "Agriculture";
 $con = mysqli_connect($dbhost, $dbuser, $dbpass , $db) or die($con);
?>