<?php
class UserSchema{

    // Connection instance
    private $connection;

    // table name
    private $table_name = "users";

    // table columns
    public $id;
    public $email;
    public $name;
    public $username; 
    public $password;
    public $type;
    public $approves_crop;
    public $approves_problem;
    public $approves_problem_type;


    

    public function __construct($connection){
        $this->connection = $connection;
    }
    //C
    public function create( $email, $name, $username, $password, $type, $approves_crop, $approves_problem, $approves_problem_type){
        $sql = "INSERT INTO `users` (`email`, `name`, `username`, `password`, `type`, `approves_crop`, `approves_problem`, `approves_problem_type`) VALUES ('$email', '$name', '$username', '$password', '$type', '$approves_crop', '$approves_problem', '$approves_problem_type')";
        $this->connection->query($sql);
    }
}